<?php

return [

    /*
    |--------------------------------------------------------------------------
    | MobileCause API Token
    |--------------------------------------------------------------------------
    |
    | This option sets the token for all API requests to the MobileCause API.
    |
    */
  'token' => env('MOBILECAUSE_TOKEN', false),
];
