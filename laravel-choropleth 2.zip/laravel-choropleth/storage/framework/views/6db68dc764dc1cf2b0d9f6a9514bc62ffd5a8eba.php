<?php $__env->startSection('content'); ?>

    <div class="row row-cards row-deck">
        <div class="col-lg-9">
            <div class="card">
                <div class="card-body">
                    <?php echo Form::open(['method' => 'POST', 'enctype' => 'multipart/form-data', 'route' => ['updatePharmacyProfile', $user->id]]); ?>

                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <?php echo Form::label('name', __('Name'), ['class' => 'form-label']); ?>

                                <?php echo Form::text('name', $user->name, ['class' => 'form-control' . ($errors->has('name') ? ' is-invalid' : '')]); ?>

                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('email', __('E-Mail'), ['class' => 'form-label']); ?>

                        <?php echo Form::text('email', $user->email, ['class' => 'form-control' . ($errors->has('email') ? ' is-invalid' : '')]); ?>


                   </div>
                    <div class="form-group">
                        <?php echo Form::label('number', __('Number'), ['class' => 'form-label']); ?>

                        <?php echo Form::text('number', $user->number, ['class' => 'form-control' . ($errors->has('number') ? ' is-invalid' : '')]); ?>

                    </div>
                    <div class="form-group" id="location-div">
                        <Label for="location" class="form-label"> Address </Label>
                        <input type="text" name="location" id="location" class="form-control" value="<?php echo e($user->location); ?>">

                    </div>
                    <div class="form-group" id="area-div">
                        <Label for="area" class="form-label"> Area </Label>
                        <input type="text" name="area" id="area" class="form-control" value="<?php echo e($user->area); ?>">
                    </div>

                    <div class="form-group" id="city-div">
                        <Label for="city" class="form-label"> City </Label>
                        <select name="city" id="city" class="form-control">
                            <option value="">Select City</option>
                            <option value="Amman" <?php if($user->city == 'Amman') {echo 'selected';} ?>>Amman</option>
                            <option value="Aqabah" <?php if($user->city == 'Aqabah') {echo 'selected';} ?>>Aqabah</option>
                            <option value="Mafraq" <?php if($user->city == 'Mafraq') {echo 'selected';} ?>>Mafraq</option>
                            <option value="At-Tafilah" <?php if($user->city == 'At-Tafilah') {echo 'selected';} ?>>At-Tafilah</option>
                            <option value="Irbid" <?php if($user->city == 'Irbid') {echo 'selected';} ?>>Irbid</option>
                            <option value="Maan" <?php if($user->city == 'Maan') {echo 'selected';} ?>>Maan</option>
                            <option value="Ajlun" <?php if($user->city == 'Ajlun') {echo 'selected';} ?>>Ajlun</option>
                            <option value="Jarash" <?php if($user->city == 'Jarash') {echo 'selected';} ?>>Jarash</option>
                            <option value="Al-Balqa" <?php if($user->city == 'Al-Balqa') {echo 'selected';} ?>>Al-Balqa</option>
                            <option value="Madaba" <?php if($user->city == 'Madaba') {echo 'selected';} ?>>Madaba</option>
                            <option value="Al-Karak" <?php if($user->city == 'Al-Karak') {echo 'selected';} ?>>Al-Karak</option>
                            <option value="Az-Zarqa" <?php if($user->city == 'Az-Zarqa') {echo 'selected';} ?>>Az-Zarqa</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <?php echo Form::label('password', __('Password'), ['class' => 'form-label']); ?>

                        <?php echo Form::password('password', ['class' => 'form-control' . ($errors->has('password ') ? ' is-invalid' : ''), 'placeholder' => 'Password']); ?>


                        <?php if($errors->has('password')): ?>
                            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($errors->first('password')); ?></strong>
            </span>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <?php echo Form::label('password_confirmation', __('Confirm Password'), ['class' => 'form-label']); ?>

                        <?php echo Form::password('password_confirmation', ['class' => 'form-control' . ($errors->has('password_confirmation ') ? ' is-invalid' : ''), 'placeholder' => 'Password Confirmation']); ?>


                        <?php if($errors->has('password_confirmation')): ?>
                            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
            </span>
                        <?php endif; ?>
                    </div>




                    <div class="row align-items-center">
                        <div class="col-auto">
                            <span class="avatar avatar-md avatar"><?php echo e(auth()->user()->initials); ?></span>
                        </div>
                        <div class="col">
                            <div><?php echo e(auth()->user()->name); ?></div>
                            <small class="d-block item-except text-sm text-muted h-1x"><?php echo e(auth()->user()->email); ?></small>
                        </div>
                    </div>
                    <div class="form-footer">
                        <button type="submit" class="btn btn-primary btn-block">Update</button>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>