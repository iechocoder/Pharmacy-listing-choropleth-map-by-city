<?php $__env->startSection('content'); ?>
<div class="col col-login mx-auto">
  <div class="text-center mb-6">
    <img src="<?php echo e($logo_url); ?>" class="h-6" alt="">
  </div>
  <div class="card">
    <div class="card-body p-6">
        <?php if(session('resent')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(__('A fresh verification link has been sent to your email address.')); ?>

            </div>
        <?php endif; ?>

        <?php echo e(__('Before proceeding, please check your email for a verification link.')); ?>

        <?php echo e(__('If you did not receive the email')); ?>, <a href="<?php echo e(route('verification.resend')); ?>"><?php echo e(__('click here to request another')); ?></a>.
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>