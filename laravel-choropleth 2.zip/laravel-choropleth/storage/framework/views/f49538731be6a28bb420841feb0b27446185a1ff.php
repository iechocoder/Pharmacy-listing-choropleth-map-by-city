<?php $__env->startSection('content'); ?>

    <div class="row row-cards row-deck">
        <div class="col-12">
            <div class="card">
                <div>
                    <h3 style="padding: 10px;display: inline-block;"> List of Users </h3>
                    <?php if(isset(\Auth::user()->type) && \Auth::user()->type == '1'): ?>
                        <a href="<?php echo e(route('addNewUser')); ?>" class="btn btn-blue col-1" style="margin: 10px;display: inline-block;float: right;">Add New</a>
                    <?php endif; ?>

                </div>
                <div class="table-responsive">
                    <table class="table table-hover table-outline table-vcenter text-nowrap card-table">
                        <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Number</th>
                            <th>City</th>
                            <th class="w-1 text-center"><i class="fe fe-settings"></i></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $pharms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="">
                                    <div><?php echo e($pos->name); ?></div>
                                </td>
                                <td>
                                    <div><?php echo e($pos->email); ?></div>
                                </td>
                                <td>
                                    <div><?php echo e($pos->number); ?></div>
                                </td>
                                <td>
                                    <div><?php echo e($pos->city); ?></div>
                                </td>

                                <td>
                                    <div style="display: inline-block;">
                                        <?php if(isset(\Auth::user()->type) && \Auth::user()->type == '1'): ?>
                                            <a class="btn btn-green" href="<?php echo e(route('trainee.view', $pos->id)); ?>"> View </a>
                                            <a class="btn btn-blue" href="<?php echo e(route('editTraineeProfile', $pos->id)); ?>">Edit</a>
                                            <a class="btn btn-danger" href="<?php echo e(route('deleteUser', $pos->id)); ?>">Delete</a>
                                        <?php endif; ?>

                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>