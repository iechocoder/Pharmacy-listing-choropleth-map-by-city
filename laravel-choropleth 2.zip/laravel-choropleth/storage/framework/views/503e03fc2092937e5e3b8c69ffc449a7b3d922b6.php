<div class="header collapse d-lg-flex p-0" id="headerMenuCollapse">
          <div class="container">
            <div class="row align-items-center">
              <div class="col-lg-3 ml-auto">
                <ul class="nav nav-tabs border-0 flex-column flex-lg-row">
                  <!--<li class="nav-item">
                    <a href="<?php echo e(route('users.index')); ?>" class="nav-link <?php echo e(Request::is('users*') ? 'active' : ''); ?>">
                      <i class="fe fe-users"></i> Users
                    </a>
                  </li>-->

                </ul>
              </div>
              <div class="col-lg order-lg-first">
                <ul class="nav nav-tabs border-0 flex-column flex-lg-row">
                  <li class="nav-item">
                    <a href="<?php echo e(route('dashboard')); ?>" class="nav-link <?php echo e(Request::is('dashboard*') ? 'active' : ''); ?>">
                      <i class="fe fe-home"></i> Home
                    </a>
                  </li>
                    <?php if(\Auth::user()->type == '1'): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.view', 1)); ?>" class="nav-link <?php echo e(Request::is('dashboard*') ? 'active' : ''); ?>">
                            <i class="fe fe-home"></i> Dashboard
                        </a>
                    </li>

                        <li class="nav-item">
                            <a href="<?php echo e(route('donations.index')); ?>" class="nav-link <?php echo e(Request::is('donations*') ? 'active' : ''); ?>">
                                <i class="fe fe-dollar-sign"></i> Pharmacies
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?php echo e(route('donations.index')); ?>" class="nav-link <?php echo e(Request::is('donations*') ? 'active' : ''); ?>">
                                <i class="fe fe-dollar-sign"></i> Users
                            </a>
                        </li>

                    <?php endif; ?>

                  <li class="nav-item">
                      <?php if(\Auth::user()->type == '2'): ?>
                          <a href="<?php echo e(route('pharmacy.view',\Auth::user()->id )); ?>" class="nav-link <?php echo e(Request::is('states*') ? 'active' : ''); ?>">
                              <i class="fe fe-globe"></i> Dashboard
                          </a>
                      <?php elseif(\Auth::user()->type == '3'): ?>
                          <a href="<?php echo e(route('trainee.view', \Auth::user()->id)); ?>" class="nav-link <?php echo e(Request::is('states*') ? 'active' : ''); ?>">
                              <i class="fe fe-globe"></i> Dashboard
                          </a>
                      <?php endif; ?>

                  </li>

                </ul>
              </div>
            </div>
          </div>
        </div>

        <?php if(false): ?>
<nav class="navbar navbar-expand-md navbar-light">
  <div class="container-fluid">
      <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
          <?php echo e(config('app.name', 'Laravel')); ?>

      </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
          <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <!-- Left Side Of Navbar -->
          <ul class="navbar-nav mr-auto">
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Pages
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="<?php echo e(route('states.index')); ?>">States</a>
                <a class="dropdown-item" href="#">Donations</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="<?php echo e(route('users.index')); ?>">User Management</a>
                <a class="dropdown-item" href="#">Site Settings</a>
              </div>
            </li>
          </ul>

          <!-- Right Side Of Navbar -->
          <ul class="navbar-nav ml-auto">
              <!-- Authentication Links -->
              <?php if(auth()->guard()->guest()): ?>
                  <li class="nav-item">
                      <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                  </li>
                  <li class="nav-item">
                      <?php if(Route::has('register')): ?>
                          <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                      <?php endif; ?>
                  </li>
              <?php else: ?>
                  <li class="nav-item dropdown">
                      <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                          <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                      </a>

                      <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                          <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                             onclick="event.preventDefault();
                                           document.getElementById('logout-form').submit();">
                              <?php echo e(__('Logout')); ?>

                          </a>

                          <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                              <?php echo csrf_field(); ?>
                          </form>
                      </div>
                  </li>
              <?php endif; ?>
          </ul>
      </div>
  </div>
</nav>
<?php endif; ?>
