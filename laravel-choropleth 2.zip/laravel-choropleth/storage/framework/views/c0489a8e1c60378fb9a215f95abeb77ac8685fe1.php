<?php $__env->startSection('content'); ?>

    <div class="row row-cards row-deck">
        <div class="col-lg-9">
            <div class="card">
                <div class="card-body">
                    <?php echo Form::open(['method' => 'PUT', 'route' => ['trainingPositions.update', $pos]]); ?>

                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <?php echo Form::label('title', 'Title', ['class' => 'form-label']); ?>

                                <input type="text" name="title" value="<?php echo e($pos->title); ?>" class="form-control">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('description', 'Due Date', ['class' => 'form-label']); ?>

                        <input type="date" name="last_apply_date"class="form-control" value="<?php echo e($pos->last_apply_date); ?>">

                    </div>

                    <div class="form-group">
                        <?php echo Form::label('is_visible', 'Is Visible', ['class' => 'form-label']); ?>

                        <select name="is_visible" id="" class="form-control">
                            <option value="1">yes</option>
                            <option value="0">no</option>
                        </select>
                    </div>

                    <input type="hidden" name="pharmacy_id" value="<?php echo e($pos->id); ?>">
                    <input type="hidden" name="is_visible" value="1">

                    <div class="row align-items-center">
                        <div class="col-auto">
                            <span class="avatar avatar-md avatar"><?php echo e(auth()->user()->initials); ?></span>
                        </div>
                        <div class="col">
                            <div><?php echo e(auth()->user()->name); ?></div>
                            <small class="d-block item-except text-sm text-muted h-1x"><?php echo e(auth()->user()->email); ?></small>
                        </div>
                    </div>
                    <div class="form-footer">
                        <button type="submit" class="btn btn-primary btn-block">Update</button>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>