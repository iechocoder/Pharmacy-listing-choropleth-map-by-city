
<div class="header py-4">
  <div class="container">
    <div class="d-flex">
      <a class="header-brand" href="<?php echo e(url('/')); ?>">
        <img src="<?php echo e($logo_url); ?>" class="header-brand-img" alt="<?php echo e(config('app.name', 'Laravel')); ?>">
      </a>
      <div class="d-flex order-lg-2 ml-auto">
      <?php if(auth()->guard()->guest()): ?>
      <div class="nav-item d-none d-md-flex">
        <a href="<?php echo e(route('register')); ?>" class="nav-link pr-0 leading-none" >
          Register
        </a>
      </div>
          <div class="nav-item d-none d-md-flex">
            <a href="<?php echo e(route('login')); ?>" class="nav-link pr-0 leading-none" >
              Login
            </a>
          </div>
      <?php else: ?>
        <div class="dropdown">
          <a href="#" class="nav-link pr-0 leading-none" data-toggle="dropdown">
            <span class="avatar avatar-<?php echo e(auth()->user()->color); ?>"><?php echo e(auth()->user()->initials); ?></span>
            <span class="ml-2 d-none d-lg-block">
              <span class="text-default"><?php echo e(Auth::user()->name); ?></span>
              <small class="text-muted d-block mt-1"><?php echo e(Auth::user()->email); ?></small>
            </span>
          </a>
          <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">

            <?php if(\Auth::user()->type == '2'): ?>
              <a class="dropdown-item" href="<?php echo e(route('pharmacy.view',\Auth::user()->id )); ?>">
                <i class="dropdown-icon fe fe-user"></i> Profile
              </a>
            <?php elseif(\Auth::user()->type == '3'): ?>
              <a class="dropdown-item" href="<?php echo e(route('trainee.view',\Auth::user()->id )); ?>">
                <i class="dropdown-icon fe fe-user"></i> Profile
              </a>
            <?php endif; ?>

            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                <i class="dropdown-icon fe fe-log-out"></i> <?php echo e(__('Logout')); ?>

            </a>

            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
          </div>
        </div>
      <?php endif; ?>
      </div>
      <a href="#" class="header-toggler d-lg-none ml-3 ml-lg-0" data-toggle="collapse" data-target="#headerMenuCollapse">
        <span class="header-toggler-icon"></span>
      </a>
    </div>
  </div>
</div>
