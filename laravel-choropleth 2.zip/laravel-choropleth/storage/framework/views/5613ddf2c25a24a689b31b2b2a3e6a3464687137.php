<?php $__env->startSection('content'); ?>
    <div class="row row-cards row-deck">
        <div class="col-12">
            <div class="card">
                <div>
                    <h3 style="padding: 10px;display: inline-block;">Applied Users</h3>

                </div>
                <div class="table-responsive">
                    <table class="table table-hover table-outline table-vcenter text-nowrap card-table">
                        <thead>
                        <tr>
                            <th>Name</th>
                            <th>Applied Date</th>
                            <th>Status</th>
                            <th class="w-1 text-center"><i class="fe fe-settings"></i></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $trainees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="">
                                    <div><?php echo e($pos->name); ?></div>
                                </td>
                                <td>
                                    <div><?php echo e($pos->created_at); ?></div>
                                </td>
                                <td class="">

                                   <?php if($pos->status == 0): ?>
                                        <div>Review</div>
                                       <?php elseif($pos->status == 1): ?>
                                        <div>Accepted</div>
                                       <?php elseif($pos->status ==2): ?>
                                        <div>Cancelled</div>
                                       <?php endif; ?>
                                </td>

                                <td>
                                    <div style="display: inline-block;">
                                        <a class="btn btn-green" href="<?php echo e(route('viewTrainee', $pos->user_id)); ?>"> Review </a>
                                    <?php if($pos->status == 0): ?>
                                            <a class="btn btn-blue" href="<?php echo e(route('updateTraineesStatus', [$pos->id, 1])); ?>">Accecpt</a>
                                            <a class="btn btn-danger" href="<?php echo e(route('updateTraineesStatus', [$pos->id, 2])); ?>">Cancel</a>
                                     <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>