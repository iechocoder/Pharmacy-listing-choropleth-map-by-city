<?php $__env->startSection('content'); ?>

    <div class="row row-cards row-deck">
        <div class="col-lg-9">
            <div class="card">
                <div class="card-body">
                    <?php echo Form::open(['method' => 'POST', 'enctype' => 'multipart/form-data', 'route' => ['updatePharmacyProfile', $user->id]]); ?>

                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <?php echo Form::label('name', __('Name'), ['class' => 'form-label']); ?>

                                <?php echo Form::text('name', $user->name, ['class' => 'form-control' . ($errors->has('name') ? ' is-invalid' : '')]); ?>

                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('email', __('E-Mail'), ['class' => 'form-label']); ?>

                        <?php echo Form::text('email', $user->email, ['class' => 'form-control' . ($errors->has('email') ? ' is-invalid' : '')]); ?>


                   </div>
                    <div class="form-group">
                        <?php echo Form::label('number', __('Number'), ['class' => 'form-label']); ?>

                        <?php echo Form::text('number', $user->number, ['class' => 'form-control' . ($errors->has('number') ? ' is-invalid' : '')]); ?>

                    </div>
                    <div class="form-group" id="location-div">
                        <Label for="location" class="form-label"> Address </Label>
                        <input type="text" name="location" id="location" class="form-control" value="<?php echo e($user->location); ?>">

                    </div>
                    <div class="form-group" id="area-div">
                        <Label for="area" class="form-label"> Area </Label>
                        <input type="text" name="area" id="area" class="form-control" value="<?php echo e($user->area); ?>">
                    </div>

                    <div class="form-group" id="city-div">
                        <Label for="city" class="form-label"> City </Label>
                        <select name="city" id="city" class="form-control">
                            <option value="">Select City</option>
                            <option value="Amman" <?php if($user->city == 'Amman') {echo 'selected';} ?>>Amman</option>
                            <option value="Az-Zarqa" <?php if($user->city == 'Az-Zarqa') {echo 'selected';} ?>>Az-Zarqa</option>
                            <option value="Irbid" <?php if($user->city == 'Irbid') {echo 'selected';} ?>>Irbid</option>
                            <option value="AL-Karak" <?php if($user->city == 'AL-Karak') {echo 'selected';} ?>>AL-Karak</option>
                            <option value="Ar-Ramtha" <?php if($user->city == 'Ar-Ramtha') {echo 'selected';} ?>>Ar-Ramtha</option>
                            <option value="Jerash" <?php if($user->city == 'Jerash') {echo 'selected';} ?>>Jerash</option>
                            <option value="Sakib" <?php if($user->city == 'Sakib') {echo 'selected';} ?>>Sakib</option>
                            <option value="Ajloun" <?php if($user->city == 'Ajloun') {echo 'selected';} ?>>Ajloun</option>
                            <option value="Al-Dalil" <?php if($user->city == 'Al-Dalil') {echo 'selected';} ?>>Al-Dalil</option>
                            <option value="Al-Husn" <?php if($user->city == 'Al-Husn') {echo 'selected';} ?>>Al-Husn</option>
                            <option value="Al-Kutaifa" <?php if($user->city == 'Al-Kutaifa') {echo 'selected';} ?>>Al-Kutaifa</option>
                            <option value="Al-Matabbah" <?php if($user->city == 'Al-Matabbah') {echo 'selected';} ?>>Al-Matabbah</option>
                            <option value="Al-Muwaqqar" <?php if($user->city == 'Al-Muwaqqar') {echo 'selected';} ?>>Al-Muwaqqar</option>
                            <option value="Al-Quwaysimah" <?php if($user->city == 'Al-Quwaysimah') {echo 'selected';} ?>>Al-Quwaysimah</option>
                            <option value="Aqaba port" <?php if($user->city == 'Aqaba port') {echo 'selected';} ?>>Aqaba port</option>
                            <option value="Arki" <?php if($user->city == 'Arki') {echo 'selected';} ?>>Arki</option>
                            <option value="Karameh" <?php if($user->city == 'Karameh') {echo 'selected';} ?>>Karameh</option>
                            <option value="Maan" <?php if($user->city == 'Maan') {echo 'selected';} ?>>Ma'an</option>
                            <option value="Madaba" <?php if($user->city == 'Madaba') {echo 'selected';} ?>>Madaba</option>
                            <option value="Russiefa" <?php if($user->city == 'Russiefa') {echo 'selected';} ?>>Russiefa</option>
                            <option value="Sahab" <?php if($user->city == 'Sahab') {echo 'selected';} ?>>Sahab</option>
                            <option value="Salt" <?php if($user->city == 'Salt') {echo 'selected';} ?>>Salt</option>
                            <option value="Souf" <?php if($user->city == 'Souf') {echo 'selected';} ?>>Souf</option>
                            <option value="Tafilah" <?php if($user->city == 'Tafilah') {echo 'selected';} ?>>Tafilah</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <?php echo Form::label('password', __('Password'), ['class' => 'form-label']); ?>

                        <?php echo Form::password('password', ['class' => 'form-control' . ($errors->has('password ') ? ' is-invalid' : ''), 'placeholder' => 'Password']); ?>


                        <?php if($errors->has('password')): ?>
                            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($errors->first('password')); ?></strong>
            </span>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <?php echo Form::label('password_confirmation', __('Confirm Password'), ['class' => 'form-label']); ?>

                        <?php echo Form::password('password_confirmation', ['class' => 'form-control' . ($errors->has('password_confirmation ') ? ' is-invalid' : ''), 'placeholder' => 'Password Confirmation']); ?>


                        <?php if($errors->has('password_confirmation')): ?>
                            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
            </span>
                        <?php endif; ?>
                    </div>




                    <div class="row align-items-center">
                        <div class="col-auto">
                            <span class="avatar avatar-md avatar"><?php echo e(auth()->user()->initials); ?></span>
                        </div>
                        <div class="col">
                            <div><?php echo e(auth()->user()->name); ?></div>
                            <small class="d-block item-except text-sm text-muted h-1x"><?php echo e(auth()->user()->email); ?></small>
                        </div>
                    </div>
                    <div class="form-footer">
                        <button type="submit" class="btn btn-primary btn-block">Update</button>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>