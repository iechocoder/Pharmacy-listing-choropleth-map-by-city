<?php $__env->startSection('content'); ?>
    <div class="row-cards row-deck">
        <div class="card">
            <div style="margin: 15px;">

                <div class="row" style="padding: 10px;">
                    <div class="col-sm-6 col-lg-5" >
                        <b> Name: </b> <?php echo e($user->name); ?>

                    </div>

                    <div class="col-sm-6 col-lg-5" style="margin-left: 1.5rem;">
                        <b> Email: </b> <?php echo e($user->email); ?>

                    </div>
                </div>
                <br>
                <div class="row">
                    <div class="col-sm-6 col-lg-5" style="margin-left: 10px;">
                        <b> Number: </b> <?php echo e($user->number); ?>

                    </div>

                    <?php if($user->cv_path): ?>
                        <div class="col-sm-6 col-lg-5">
                            <a href="<?php echo e(route('downloadTraineeCv', $user->id)); ?>" class="btn btn-danger">Download CV</a>
                        </div>
                    <?php endif; ?>

                </div>
                <br>
            </div>
        </div>

    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>