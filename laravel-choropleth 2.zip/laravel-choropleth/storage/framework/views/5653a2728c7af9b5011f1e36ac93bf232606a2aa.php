<?php $__env->startSection('content'); ?>
    <div class="row-cards row-deck">
        <div class="card">
            <div style="margin: 15px;">
               <?php if(\Auth::user()->type == '3'): ?>
                <a href="<?php echo e(route('editTraineeProfile', $user->id)); ?>" class="btn btn-blue" style="float: right;">Edit</a>
                <?php endif; ?>

                <div class="row">
                <div class="col-sm-6 col-lg-5" >
                    <b> Name: </b> <?php echo e($user->name); ?>

                </div>

                <div class="col-sm-6 col-lg-5" style="margin-left: 1.5rem;">
                    <b> Email: </b> <?php echo e($user->email); ?>

                </div>
            </div>
            <br>
            <div class="row">
                <div class="col-sm-6 col-lg-5" style="margin-left: 10px;">
                    <b> Number: </b> <?php echo e($user->number); ?>

                </div>

                <?php if($user->cv_path): ?>
                    <div class="col-sm-6 col-lg-5">
                        <a href="<?php echo e(route('downloadTraineeCv', $user->id)); ?>" class="btn btn-danger">Download CV</a>
                    </div>
                <?php endif; ?>
            </div>
            <br>

            </div>
        </div>

    </div>

    <div class="row row-cards row-deck">
        <div class="col-12">
            <div class="card">
                <div>
                <h3 style="padding: 10px;display: inline-block;">Applied Training Positions</h3>

                </div>
                <div class="table-responsive">
                    <table class="table table-hover table-outline table-vcenter text-nowrap card-table">
                        <thead>
                        <tr>
                            <th>Position</th>
                            <th>Pharmacy</th>
                            <th class="w-1">Applied Date</th>
                            <th class="w-1">Status</th>

                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $userTrainings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="">
                                    <div><?php echo e($pos->tpTitle); ?></div>
                                </td>
                                <td>
                                    <div><?php echo e($pos->name); ?></div>
                                </td>
                                <td class="">
                                    <div><?php echo e($pos->created_at); ?></div>
                                </td>
                                <td class="">
                                    <?php if($pos->status == 0): ?>
                                        <label for="" class="btn-blue" style="padding: 2px;">In Process</label>
                                    <?php elseif($pos->status == 1): ?>
                                        <label for="" class="btn-green"  style="padding: 2px;">Accepted</label>
                                    <?php elseif($pos->status == 2): ?>
                                        <label for="" class="btn-danger" style="padding: 2px;">Cancelled</label>

                                    <?php endif; ?>


                                </td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        $(function(){
            $(':checkbox').each(function() {
                $(this).change(function() {
                    var $form = $(this).closest("form");

                    $form.submit();

                    console.log($form);
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>