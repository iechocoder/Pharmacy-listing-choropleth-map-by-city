<?php $__env->startSection('content'); ?>
<div class="row row-cards">
  <div class="col-sm-6 col-lg-4">
    <div class="card p-3">
      <div class="d-flex align-items-center">
        <span class="stamp stamp-md bg-blue mr-3">
          <i class="fe fe-hash"></i>
        </span>
        <div>
          <h4 class="m-0"><?php echo e($states->filter(function($state) { return $state->donations->isEmpty(); })->count()); ?></h4>
          <small class="text-muted">States without donations</small>
        </div>
      </div>
    </div>
  </div>
  <div class="col-sm-6 col-lg-4">
    <div class="card p-3">
      <div class="d-flex align-items-center">
        <span class="stamp stamp-md bg-blue mr-3">
          <i class="fe fe-award"></i>
        </span>
        <div>
          <h4 class="m-0"><?php echo e($states->sortByDesc(function ($state) { return $state->donations->sum('amount'); })->first()->name); ?></h4>
          <small class="text-muted">Most donations</small>
        </div>
      </div>
    </div>
  </div>
  <div class="col-sm-6 col-lg-4">
    <div class="card p-3">
      <div class="d-flex align-items-center">
        <span class="stamp stamp-md bg-blue mr-3">
          <i class="fe fe-award"></i>
        </span>
        <div>
          <h4 class="m-0"><?php echo e($states->sortByDesc('donations_count')->first()->name); ?></h4>
          <small class="text-muted">Most donated</small>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="row row-cards row-deck">
  <div class="col-12">
    <div class="card">
      <div class="table-responsive">
        <table class="table table-hover table-outline table-vcenter text-nowrap card-table">
          <thead>
            <tr>
              <th>State</th>
              <th>Donations</th>
              <th>Donation Activity</th>
              <th class="w-1">Visible</th>
              <th class="w-1 text-center"><i class="fe fe-settings"></i></th>
            </tr>
          </thead>
          <tbody>
          <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td class="w-1">
                <div><?php echo e($state->abbreviation); ?></div>
                <div class="small text-muted">
                  <?php echo e($state->name); ?>

                </div>
              </td>
              <td>
              <?php if( $state->donations_count > 0 ): ?>
                <div class="clearfix">
                  <div class="float-left">
                    <strong>$<?php echo e(number_format($state->donations->sum('amount'), 2)); ?></strong>
                  </div>
                  <div class="float-right">
                    <small class="text-muted"><?php echo e($state->donations_count); ?> Donations</small>
                  </div>
                </div>
                <div class="progress progress-xs">
                  <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo e($state->donations->sum('amount') * 100 / $donation_amount); ?>%" aria-valuenow="<?php echo e($state->donations->sum('amount') * 100 / $donation_amount); ?>" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
              <?php else: ?>
                <div class="clearfix">
                  <div class="float-left">
                    <strong>$0.00</strong>
                  </div>
                  <div class="float-right">
                    <small class="text-muted">No Donations</small>
                  </div>
                </div>
                <div class="progress progress-xs">
                  <div class="progress-bar bg-success" role="progressbar" style="width: 0%" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
              <?php endif; ?>
              </td>
              <td class="w-1">
              <?php if( $state->donations_count > 0 ): ?>
                <div><?php echo e($state->donations()->latest()->first()->created_at->diffForHumans()); ?></div>
                <div class="small text-muted">
                  Last Donation
                </div>
              <?php endif; ?>
              </td>
              <td class="w-1">
                <?php echo Form::model($state, ['method' => 'PATCH', 'route' => ['states.update', $state]]); ?>

                <div class="form-group m-0">
                  <?php if( $state->donations->isNotEmpty() ): ?>
                    <label class="custom-switch disabled" title="Cannot hide a state which has donations.">
                  <?php else: ?>
                    <label class="custom-switch">
                  <?php endif; ?>
                    <?php echo Form::hidden('is_visible', 0); ?>

                    <?php echo Form::checkbox('is_visible', 1, null, ['class' => "custom-switch-input", 'disabled' => $state->donations->isNotEmpty()]); ?>

                    <span class="custom-switch-indicator"></span>
                  </label>
                </div>
                <?php echo Form::close(); ?>

              </td>
              <td class="w-1 text-center">
                <div class="item-action dropdown">
                  <a href="javascript:void(0)" data-toggle="dropdown" class="icon"><i class="fe fe-more-vertical"></i></a>
                  <div class="dropdown-menu">
                    <a href="<?php echo e(route('states.show', $state)); ?>" class="dropdown-item"><i class="dropdown-icon fe fe-activity"></i> View</a>
                    <a href="javascript:void(0)" class="dropdown-item"><i class="dropdown-icon fe fe-edit-2"></i> Edit</a>
                  </div>
                </div>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
  $(function(){
    $(':checkbox').each(function() {
      $(this).change(function() {
        var $form = $(this).closest("form");

        $form.submit();

        console.log($form);
      });
    });
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>