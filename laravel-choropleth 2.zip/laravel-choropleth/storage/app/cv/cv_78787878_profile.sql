# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 127.0.0.1 (MySQL 5.6.38)
# Database: registrationdb
# Generation Time: 2020-06-09 17:20:18 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table Customer_has_subscriptions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Customer_has_subscriptions`;

CREATE TABLE `Customer_has_subscriptions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Customer_id` int(11) NOT NULL,
  `Asset_id` int(11) NOT NULL,
  `subscription_levels_id` int(11) unsigned NOT NULL,
  `type` enum('sphere_base','sphere_storage') DEFAULT NULL,
  `provider` enum('bluesnap','xchange') DEFAULT NULL,
  `provider_subscription_id` varchar(255) DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `storage_gigabytes_included` int(10) unsigned DEFAULT NULL,
  `cancel_date` datetime DEFAULT NULL,
  `cancel_reason` varchar(255) DEFAULT NULL,
  `cancel_party` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_Customer_has_subcriptions_Customer1_idx` (`Customer_id`),
  KEY `fk_Customer_has_subcriptions_subscription_levels1_idx` (`subscription_levels_id`),
  KEY `fk_Customer_has_subscriptions_Asset1_idx` (`Asset_id`),
  CONSTRAINT `fk_Customer_has_subcriptions_Customer1` FOREIGN KEY (`Customer_id`) REFERENCES `Customer` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `fk_Customer_has_subcriptions_subscription_levels1` FOREIGN KEY (`subscription_levels_id`) REFERENCES `subscription_levels` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `fk_Customer_has_subscriptions_Asset1` FOREIGN KEY (`Asset_id`) REFERENCES `Asset` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `Customer_has_subscriptions` WRITE;
/*!40000 ALTER TABLE `Customer_has_subscriptions` DISABLE KEYS */;

INSERT INTO `Customer_has_subscriptions` (`id`, `Customer_id`, `Asset_id`, `subscription_levels_id`, `type`, `provider`, `provider_subscription_id`, `start_date`, `end_date`, `storage_gigabytes_included`, `cancel_date`, `cancel_reason`, `cancel_party`)
VALUES
	(11,660289,10051967,3,'sphere_base','bluesnap','19061353','2020-04-14 00:00:00','2021-04-14 00:00:00',30,NULL,NULL,NULL),
	(12,660289,10051972,6,'sphere_storage','bluesnap','19061355','2020-04-14 00:00:00','2021-04-14 00:00:00',70,NULL,NULL,NULL),
	(14,2752659,10052004,2,'sphere_base','bluesnap','19378503','2020-05-06 00:00:00','2020-06-06 00:00:00',30,NULL,NULL,NULL),
	(16,880848,10052011,2,'sphere_base','bluesnap','','2020-05-12 00:00:00','2020-06-12 00:00:00',30,NULL,NULL,NULL),
	(17,1531516,10052012,3,'sphere_base','bluesnap','','2020-05-12 00:00:00','2021-05-12 00:00:00',30,NULL,NULL,NULL),
	(19,2752660,10052022,2,'sphere_base','bluesnap','','2020-05-13 00:00:00','2020-06-13 00:00:00',30,NULL,NULL,NULL),
	(20,2748035,10052023,2,'sphere_base','bluesnap','','2020-05-13 00:00:00','2020-06-13 00:00:00',30,NULL,NULL,NULL),
	(21,2752661,10052034,2,'sphere_base','bluesnap','','2020-05-15 00:00:00','2020-06-15 00:00:00',30,NULL,NULL,NULL),
	(22,2752662,10052035,2,'sphere_base','bluesnap','','2020-05-15 00:00:00','2020-06-15 00:00:00',30,NULL,NULL,NULL),
	(23,2752659,10052197,5,'sphere_storage','bluesnap','19674425','2020-05-21 00:00:00','2020-06-21 00:00:00',70,NULL,NULL,NULL),
	(24,2752665,10052208,2,'sphere_base','bluesnap','','2020-05-27 00:00:00','2020-06-27 00:00:00',30,NULL,NULL,NULL),
	(27,2752675,10052396,2,'sphere_base','bluesnap','','2020-06-04 00:00:00','2020-07-04 00:00:00',30,NULL,NULL,NULL),
	(28,2752676,10052398,2,'sphere_base','bluesnap','','2020-06-04 00:00:00','2020-07-04 00:00:00',30,NULL,NULL,NULL);

/*!40000 ALTER TABLE `Customer_has_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
