export var pyDepartmentsData = [

  {
    department_id: 1,
    department_name: "Amman",
    amount_w: 5
  },
  {
    department_id: 2,
    department_name: "Aqabah",
    amount_w: 10
  },
  {
    department_id: 3,
    department_name: "Mafraq",
    amount_w: 15
  },
  {
    department_id: 4,
    department_name: "At-Tafilah",
    amount_w: 8
  },
  {
    department_id: 5,
    department_name: "Maan",
    amount_w: 9
  },
  {
    department_id: 6,
    department_name: "Irbid",
    amount_w: 22
  },
  {
    department_id: 7,
    department_name: "Ajlun",
    amount_w: 25
  },
  {
    department_id: 8,
    department_name: "Jarash",
    amount_w: 6
  },
  {
    department_id: 9,
    department_name: "Al-Balqa",
    amount_w: 9
  },
  {
    department_id: 10,
    department_name: "Madaba",
    amount_w: 15
  },
  {
    department_id: 11,
    department_name: "Al Karak",
    amount_w: 20
  },
  {
    department_id: 12,
    department_name: "Az-Zarqa",
    amount_w: 30
  }
]
