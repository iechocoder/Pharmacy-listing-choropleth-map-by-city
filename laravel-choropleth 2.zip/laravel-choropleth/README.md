# laravel-choropleth
Generate a choropleth map from an external source
