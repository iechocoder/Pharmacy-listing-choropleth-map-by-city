
var statesData =  {"type":"FeatureCollection","features":[
        {"type":"Feature","id":"01","properties":{"name":"Amman","density":94.65},"geometry":{"type":"Polygon","coordinates":[[[31.9515694,35.9239625]
                [31.95070569644172, 35.930099487304695],[31.95165245109773,35.918855667114265,[31.95019590143172,35.917825698852546],
                [31.9481566931029,35.9220314025879],['31.946554426235302',35.92452049255372]]]]}},
        {"type":"Feature","id":"02","properties":{"name":"Alabama","density":56},"geometry":{"type":"Polygon","coordinates":[[[36.834062,
                    32.312938]]]}},
        {"type":"Feature","id":"03","properties":{"name":"Alabama","density":67},"geometry":{"type":"Polygon","coordinates":[[[38.792341,
                    33.378686]]]}},
        {"type":"Feature","id":"04","properties":{"name":"Alabama","density":56},"geometry":{"type":"Polygon","coordinates":[[[39.195468,
                    32.161009]]]}},
        {"type":"Feature","id":"05","properties":{"name":"Alabama","density":89},"geometry":{"type":"Polygon","coordinates":[[[39.004886,
                    32.010217]]]}},
        {"type":"Feature","id":"05","properties":{"name":"Alabama","density":50},"geometry":{"type":"Polygon","coordinates":[[[37.002166,
                    31.508413]]]}},
        {"type":"Feature","id":"07","properties":{"name":"Alabama","density":60},"geometry":{"type":"Polygon","coordinates":[[[37.998849,
                    30.5085]]]}},
        {"type":"Feature","id":"08","properties":{"name":"Alabama","density":75},"geometry":{"type":"Polygon","coordinates":[[[37.66812,
                    30.338665]]]}},
        {"type":"Feature","id":"09","properties":{"name":"Alabama","density":80},"geometry":{"type":"Polygon","coordinates":[[[37.503582,
                    30.003776]]]}},
        {"type":"Feature","id":"10","properties":{"name":"Alabama","density":86},"geometry":{"type":"Polygon","coordinates":[[[36.740528,
                    29.865283]]]}},

    ]};

